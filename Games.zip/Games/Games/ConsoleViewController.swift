//
//  ConsoleViewController.swift
//  Games
//
//  Created by Usuário Convidado on 24/05/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import UIKit

class ConsoleViewController: UIViewController {

    // MARK: - IBOutlets
    
    @IBOutlet weak var lbName: UILabel!
    @IBOutlet weak var lbManufacturer: UILabel!
    
    @IBOutlet weak var lbReleaseDate: UILabel!
    
    @IBOutlet weak var lbUnitsSold: UILabel!
    
    
    // Recuperando o console

    var console : Console!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Dizendo que o titiulo e o proprio nome do videogame
        
        title = console.name
        
        lbName.text = "Nome : \(console.name)"
        lbManufacturer.text = "Empresa : \(console.manufacturer)"
        lbReleaseDate.text = "Lancamento : \(console.releaseDate)"
        lbUnitsSold.text = " Unidades vendidas \(console.unitsSold)"
    }

  

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
