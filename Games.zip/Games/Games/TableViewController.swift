//
//  TableViewController.swift
//  Games
//
//  Created by Usuário Convidado on 24/05/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {
    
    
    // TableView , Reutiliza as celular o tempo inteiro igual escada rolante
    
    
    // Passando minha struct dentro do array
    
    var consoles: [Console] = []

    override func viewDidLoad() {
        super.viewDidLoad()

      loadConsole()
    }

 
// Carregando meu console
    
    func loadConsole(){
        
        // Recuperando o arquivo json
        // Passando o nome do arquivo
        // Extensao do arquivo que sera "json"
        
        guard let url = Bundle.main.url(forResource : "consoles" , withExtension: "json") else {return}
        
        do {
            
            let data = try Data(contentsOf: url)
            consoles = try JSONDecoder().decode([Console].self, from: data)
            tableView.reloadData()
            
        } catch {
            print(error.localizedDescription)
        }
    }
    
    // Passando informacao de uma tela para outra
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        // Recuperando a proxima tela
        
        let vc = segue.destination as! ConsoleViewController // Me entrega as classes que serao apresentadas
        
        // Retorna a linha que eu cliquei ou seja o videogamne
        let console = consoles[tableView.indexPathForSelectedRow!.row]
        
        // Passando para proxima tela de destino
        
        vc.console = console
    }
    
    // =======================================================================
    
    // MARK: - Table view data source
    
    // Lista de sessao , Onde eu posso ver separacao de elemento , como nomes so com a letra A
    // Quando minha sessao so for apenas uma , eu nao preciso ter ele
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    // =======================================================================
    
    // Mostrar um limitador de linha ou seja retorno o numero de linhas na minha tabela
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return consoles.count
    }

    
    // CellfirRowAt - Nos usamos para retornar para tabela qual 'e a celula que ele vai mostrar para aquele elemento especifico
        // Ou seja qual tela eu vou usar e quais informacoes dentro dela
    
            // DequeuReusableCell - Constroi a celula , e vc passa o identificador criado para a tabela
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)

        // Configure the cell... ou seja configurar oq vai mostrar
        
        
        
        // Recuperando o json , IndexPath - Ele me diz a sessao da celula e me diz a linha da sessao de qual a celula faz parte
        
        // Me entrega a linha da celula , Lendo o array
        
        let console = consoles[indexPath.row]
        
        
        // Devolve o label esquerdo e recuperando os dados do Array meu json
        
        cell.textLabel?.text = console.name
        cell.detailTextLabel?.text = console.manufacturer

        return cell
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
