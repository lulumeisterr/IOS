//
//  Consoles.swift
//  Games
//
//  Created by Usuário Convidado on 24/05/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import Foundation

struct Console : Codable {
    
    let name: String
    let manufacturer: String
    let releaseDate: String
    let unitsSold: Double
    
}
