//
//  HelloController.swift
//  HellowUniverse
//
//  Created by Usuário Convidado on 15/03/2018.
//  Copyright © 2018 Usuário Convidado. All rights reserved.
//

import UIKit

class HelloController: UIViewController {

    @IBOutlet weak var lbHello: UILabel!
    
    @IBAction func changeLabel(_ sender: Any) {
        
        lbHello.text = "Ola Universo !!"
        
    }
    
}
