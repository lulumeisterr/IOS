//
//  GameViewController.swift
//  MyGames
//
//  Created by Usuário Convidado on 24/08/2018.
//  Copyright © 2018 FIAP. All rights reserved.
//

import UIKit

class GameViewController: UIViewController {

    @IBOutlet weak var txConsole: UITextField!
    @IBOutlet weak var tfName: UITextField!
    @IBOutlet weak var btAddEdit: UIButton!
    
    var game : Game!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        if game != nil {
            tfName.text = game.name
            txConsole.text = game.console
            btAddEdit.setTitle("Editar Game", for: .normal)
        }
        
    }

    // Editando e cadastrando
    
    @IBAction func addEditGame(_ sender: Any) {
        if game == nil {
            game = Game(context: context)
        }
        game.name = tfName.text
        game.console = txConsole.text
        //Salvando no contexto
        try?context.save()
        // Voltar
        navigationController?.popViewController(animated: true)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
