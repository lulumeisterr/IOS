//
//  ViewController.swift
//  CicloDeVida
//
//  Created by Usuário Convidado on 12/04/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Label: UILabel!
    @IBOutlet weak var textField: UITextField!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let nome = "Seu nome é : "
        Label.text = nome + "" + textField.text!;
        view.endEditing(true) // Tirando o foco do elemento
    }
    
    override func viewDidLoad() {
        super.viewDidLoad() // Saber o momento exato quando uma view for carregada
        print("Tela 1 : viewDidLoad (View foi carregada)")
        
        Label.text = "Olá , bem vindo"
    }

//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning() // Sempre despara quando o seu app esta com falta de memoria
//                                        // Antes de isso acontecer ele executa esse metodo
//
//    }
    
    //Vai aparecer
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Tela 1 : viewWillAppear (View vai aparecer)")
    }
    
    //Apareceu
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
         print("Tela 1 : viewWillDidAppear (View aparecer)")
    }
    
    //Desaparecer
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("Tela 1 : viewDisapper (View desapareceu)")
    }


}

