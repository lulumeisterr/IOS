//
//  SecondViewController.swift
//  CicloDeVida
//
//  Created by Usuário Convidado on 12/04/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    //Carrega
    override func viewDidLoad() {
        super.viewDidLoad() // Saber o momento exato quando uma view for carregada
        print("Tela 2 : viewDidLoad (View foi carregada)")
    }
    
    //Vai aparecer
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Tela 2 : viewWillAppear (View vai aparecer)")
    }
    
    //Apareceu
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("Tela 2 : viewWillDidAppear (View aparecer)")
    }
    
    //Desaparecer
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("Tela 2 : viewDisapper (View desapareceu)")
    }


}
