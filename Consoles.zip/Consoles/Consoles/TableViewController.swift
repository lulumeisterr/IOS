//
//  TableViewController.swift
//  Consoles
//
//  Created by Usuário Convidado on 11/06/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    // Passando minha struct dentro do array Ou seja criamos uma variavel que vai
    // Armazenar a lista de consoles
    
    var consolex : [ConsoleJson] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()

        loadConsole()
        
    }
    
    func loadConsole(){
        // Carregando meu console
        // Recuperando o arquivo json
        // Passando a extensao do arquivo que sera json
        
        // Recuperando a url do arquivo
        guard let url = Bundle.main.url(forResource: "consoles", withExtension: "json")else{return}
        
        do {
            // Criando a representacao binaria do arquivo
            let data = try Data(contentsOf: url)
            
            // Decodificando o JSON em um array de Console
            
            // Minha variavel                       //Meu arquivo JSON
            consolex = try JSONDecoder().decode([ConsoleJson].self, from: data)
            
            tableView.reloadData()
            
        }catch{
            print(error.localizedDescription)
        }
    
    }
    
    // Passando informaco de uma tela para outra
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      // Recuperar a tela que vai aparecer
        
        let rec = segue.destination as! ViewController
        
        // Devolvendo a tela selecionada com os itens
        
        let con = consolex[tableView.indexPathForSelectedRow!.row]
        
        rec.consolex = con
        
    }
    
    
    // Lista de sessao , Onde eu posso ver seapracao de elementos , com nomes so com a letra A
    // Quando minha sessao for apenas uma eu nao preciso dela
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    
    // Mostra um limitador de linha ou seja retorno o numero de linhas da minha tablea
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return consolex.count
    }
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        //dequeueReusable - Constroi a celula , vc passa o identificador criado para a tabela
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for : indexPath)
        
        // Recuperando o console relatio a aquela celula
        // Ele me entrega a linha da celular
        // IndexPath me diz a sessao da celula e me diz a linha da sessao de qual celula faz partes
        
        let c = consolex[indexPath.row]
        
        // Definindo as labels esquerdo e recuperando os dados do array do meu json
        
        cell.textLabel?.text = c.name
        cell.detailTextLabel?.text = c.manufacturer
        
        return cell;

    }
    
    
    
    
    
    


}
