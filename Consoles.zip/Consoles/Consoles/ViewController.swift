//
//  ViewController.swift
//  Consoles
//
//  Created by Usuário Convidado on 11/06/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // Associar meu struct
    
    var consolex : ConsoleJson!
    
    @IBOutlet weak var ConsoleImagem: UIImageView!
    @IBOutlet weak var fabricante: UILabel!
    @IBOutlet weak var UnidadeVendida: UILabel!
    @IBOutlet weak var Lancamento: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = consolex.name
        fabricante.text = "Fabricante : \(consolex.manufacturer)"
        Lancamento.text = "Lançamento : \(consolex.releaseDate)"
        UnidadeVendida.text = "Unidade vendidas : \(consolex.unitsSold)"
        ConsoleImagem.image = UIImage(named: consolex.image)
    }
}
