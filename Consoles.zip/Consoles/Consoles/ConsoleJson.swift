//
//  ConsoleJson.swift
//  Consoles
//
//  Created by Usuário Convidado on 11/06/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import Foundation

struct ConsoleJson : Codable {
    
    let name : String
    let manufacturer : String
    let releaseDate : String
    let unitsSold : Double
    let image : String
    
    
}
