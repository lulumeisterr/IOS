//
//  ViewController.swift
//  IMC
//
//  Created by Usuário Convidado on 19/04/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var peso: UITextField!
    @IBOutlet weak var Altura: UITextField!
    @IBOutlet weak var Resultado: UILabel!
    
    //Despara quando o usuario toca na tela
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        view.endEditing(true) // Desaparecendo o teclado
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
   
    @IBAction func Calculate(_ sender: Any) -> (){
        
     // Recuperando o valor Desembrulhando
        
        //Criando a variavel e mantendo para o desembrulhando
        guard let weight = Double(peso.text!)  else {Resultado.text = "Valores invalidos"; return}
        guard let height = Double(Altura.text!) else {Resultado.text = "Valores invalidos"; return}
        
        //Recuperando a tupla , Realizando a decomposicao de tupla
        
        let (_ , imc) = calculateIMC(weight: weight, height: height)
        
        // Mostrando no label
        
        //rawValue recupera o valor do enum
        Resultado.text = "O seu IMC é \(imc.rawValue)"
    }
    
    func calculateIMC(weight: Double, height: Double) -> (value: Double, result: IMCValue) {
        
        let value = weight/(height*height)
        var result: IMCValue!
        
        switch value {
        case 0..<16:
            result = .thinness
        case 16..<18.5:
            result = .under
        case 18.5..<25:
            result = .ideal
        case 25..<30:
            result = .over
        default:
            result = .obesity
        }
        return (value, result)
    }
    
}

