//
//  EnumIMC.swift
//  IMC
//
//  Created by Usuário Convidado on 19/04/2018.
//  Copyright © 2018 Lucas. All rights reserved.
//

import Foundation


enum IMCValue : String{

        case thinness = "magreza"
        case under = "abaixo do peso"
        case ideal = "peso ideal"
        case over = "sobrepeso"
        case obesity = "obesidade"
}
