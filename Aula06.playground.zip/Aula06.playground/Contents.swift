//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


//Classes

class Vehicle {
    
    var speed : UInt
    var model : String
    
    //Propriedade de classe , Voce Acessa ela Chamando o nome da classe . atributo
    static let SpeedUnit : String  = "KM/H"
    
    //Variavel computada ela nao armazena nada da memoria
    
    var information : String {
        return " O Carro esta a \(speed) km/H "
    }
    
    // Metodo de classe
    
    class func alert() -> String {
        return "Se beber ,  nao dirija !!!"
    }
    
    //Construtor
    
    init(speed : UInt , model : String) {
        self.speed = speed
        self.model = model
        
    }
    
}

//Variavel computada
//let vehicle = Vehicle(speed : 200 , model : "Fusca Turbinado")

print("A unidade de medida de velocidade é \(Vehicle.SpeedUnit)")

print(Vehicle.alert())

//Heranca
class Car : Vehicle {
    var licensePlate : String
    
    init(licensePlate : String , speed : UInt , model : String , information : String){
    
    self.licensePlate = licensePlate
        
       //Inicializando os atributos da classe mae no construtor
        super.init(speed: speed, model: model)
        
    }
   
}
Vehicle.SpeedUnit
